var startDate = new Date("01/01/2022");
var endDate = new Date("12/31/2022");
var monthLabel=document.getElementById('month');
var dateLabel=document.getElementById('date');
var d = startDate;

window.onload=function(){  
    var refreshId = setInterval( function() {
      if (d > endDate) {
        clearInterval(refreshId);
      } else {
        monthLabel.innerHTML = d.toLocaleString('default', { month: 'short' }).toUpperCase();
        dateLabel.innerHTML = d.getDate();
        d.setDate(d.getDate() + 1);
      }
    }, 100);
  };